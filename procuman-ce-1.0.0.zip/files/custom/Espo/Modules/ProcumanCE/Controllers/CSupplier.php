<?php

namespace Espo\Modules\ProcumanCE\Controllers;

class CSupplier extends \Espo\Core\Templates\Controllers\Company
{
}
