<?php

namespace Espo\Modules\ProcumanCE\Controllers;

class CPurchaseOrder extends \Espo\Core\Templates\Controllers\Base
{
}
