<?php

namespace Espo\Modules\ProcumanCE\Controllers;

class CPurchaseOrderLine extends \Espo\Core\Templates\Controllers\Base
{
}
