<?php

namespace Espo\Modules\ProcumanCE\Controllers;

class CProduct extends \Espo\Core\Templates\Controllers\Base
{
}
